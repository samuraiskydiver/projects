API_KEY = 'youralpacaapikey'
API_SECRET = 'youralpacaapisecret'

WEBHOOK_PASSPHRASE = 'yourpassphrase'
DISCORD_WEBHOOK_URL = False # use a string containing your discord webhook url to enable