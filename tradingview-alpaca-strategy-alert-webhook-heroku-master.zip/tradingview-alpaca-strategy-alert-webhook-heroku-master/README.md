# tradingview-alpaca-strategy-alert-webhook-heroku
TradingView Strategy Alert Webhook for Alpaca and Discord, including Heroku Procfile

## YouTube Tutorial on how to use this code

https://www.youtube.com/watch?v=XPTb3adEQEE
